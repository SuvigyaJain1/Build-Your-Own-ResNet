from setuptools import setup

setup(
	name="ResNet",
	version="0.0.1",
	description="Simple API to build a resnet type architecture using keras",
	py_modules=["ResNet"],
	packages_dir={'':'src'},
	)